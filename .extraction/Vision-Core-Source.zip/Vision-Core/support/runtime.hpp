#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <iterator>
inline constexpr int    kNetMax = 640;
inline constexpr size_t kTensorFloatsMax = size_t(kNetMax) * kNetMax * 3;

inline const wchar_t* kModelCandidates[] = {
    L"yolov8n.engine", L"yolov8n.plan", L"yolov8n.trt", L"yolov8n.onnx"
};
inline const wchar_t* kModelName = L"yolov8n.onnx";
inline constexpr float kConfThr = 0.35f;
inline constexpr int    kDecodeClass = 0;
inline std::atomic<float> gDecodeConf{ kConfThr };
inline std::atomic<int> gNetSize{ kNetMax };
inline size_t TensorFloatsFor(int net) noexcept { return size_t(net) * size_t(net) * 3; }
inline std::atomic<int> gOutCh{ 0 };
inline std::atomic<int> gOutAnchors{ 0 };
inline constexpr float kIouThr = 0.45f;

inline const char* kClassNames[] = {
    "person","bicycle","car","motorcycle","airplane","bus","train","truck","boat",
    "traffic light","fire hydrant","stop sign","parking meter","bench","bird","cat",
    "dog","horse","sheep","cow","elephant","bear","zebra","giraffe","backpack",
    "umbrella","handbag","tie","suitcase","frisbee","skis","snowboard","sports ball",
    "kite","baseball bat","baseball glove","skateboard","surfboard","tennis racket",
    "bottle","wine glass","cup","fork","knife","spoon","bowl","banana","apple",
    "sandwich","orange","broccoli","carrot","hot dog","pizza","donut","cake","chair",
    "couch","potted plant","bed","dining table","toilet","tv","laptop","mouse",
    "remote","keyboard","cell phone","microwave","oven","toaster","sink",
    "refrigerator","book","clock","vase","scissors","teddy bear","hair drier","toothbrush"
};
inline constexpr int kNumClasses = int(std::size(kClassNames));

